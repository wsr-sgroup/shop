package com.project.platform.vo;

import lombok.Data;

@Data
public class FileInfoVO {
    private String url;
    private String name;
}
