<template>
  <div>
    <el-row :gutter="20">
        首页
    </el-row>

  </div>
</template>
<script setup></script>
